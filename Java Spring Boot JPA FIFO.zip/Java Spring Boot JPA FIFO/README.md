# NEW-46 – Spring Boot JPA FIFO PoC

Java 17, Spring Boot 3.3.5, Spring Data JPA/Hibernate, PostgreSQL 16 for local demo and H2 for automated tests.

This is a design-validation PoC, not the production application. Auth/JWT is TV1; Order/Payment is TV3; telemetry/hardware control is TV4.

## Start PostgreSQL
From this directory:

```powershell
docker compose up -d
```

PostgreSQL listens on `localhost:5433`. On first initialization it runs the TV2 DDL and seed script mounted from `database/tv2`.

`docker compose down -v` deletes the local demo database volume and all its data. Use only when you intend to reset the demo database.

## Test and run

```powershell
mvn test
mvn spring-boot:run
```

Tests use H2 and do not require Docker.

POST `http://localhost:8081/api/v1/inventory/issues`:

```json
{
  "productId": 1,
  "slotId": 1,
  "quantity": 7,
  "asOfDate": "2026-11-25",
  "referenceId": "DEMO-ISSUE-001",
  "actorId": "tv2-demo"
}
```

The oldest eligible batch is allocated first. Expired batches are excluded. Insufficient stock throws an exception and rolls back partial allocations.

## Boundaries

The local controller accepts `actorId` only for demo convenience. Production must derive identity from TV1's authenticated principal. The PoC implements FIFO issue; Product CRUD, restock API, scheduled alert jobs and final shared exception envelope are specified in TV2 API/docs for integration into the team's main Spring Boot project.

Maven was unavailable in the generation environment. Run `mvn test` locally and attach actual build/test evidence to the Pull Request; this package does not claim the Maven build has already passed.
