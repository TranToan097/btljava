package vn.freshvend.tv2.service;

import static org.assertj.core.api.Assertions.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import vn.freshvend.tv2.domain.*;
import vn.freshvend.tv2.repository.*;

@SpringBootTest
@ActiveProfiles("test")
class FifoAllocationServiceTest {
    @Autowired private FifoAllocationService service;
    @Autowired private ProductRepository productRepository;
    @Autowired private InventoryBatchRepository batchRepository;
    @Autowired private MachineSlotRepository slotRepository;
    @Autowired private InventoryStockRepository stockRepository;
    @Autowired private InventoryMovementRepository movementRepository;

    private Product product;
    private MachineSlot slot;
    private InventoryBatch oldest;
    private InventoryBatch newest;

    @BeforeEach
    void setUp() {
        movementRepository.deleteAll();
        stockRepository.deleteAll();
        batchRepository.deleteAll();
        slotRepository.deleteAll();
        productRepository.deleteAll();

        product = productRepository.save(new Product(
            1L, "TEST-FRUIT-01", "Test Fruit Bowl", new BigDecimal("35000.00"), "bowl"
        ));
        slot = slotRepository.save(new MachineSlot(1L, "A1", product.getId(), 20, "ACTIVE"));

        oldest = batchRepository.save(new InventoryBatch(
            product.getId(), "BATCH-OLD", LocalDate.of(2026, 11, 20),
            LocalDate.of(2026, 11, 27), 5, "AVAILABLE"
        ));
        newest = batchRepository.save(new InventoryBatch(
            product.getId(), "BATCH-NEW", LocalDate.of(2026, 11, 22),
            LocalDate.of(2026, 11, 29), 10, "AVAILABLE"
        ));

        stockRepository.save(new InventoryStock(oldest.getId(), product.getId(), slot.getId(), 5));
        stockRepository.save(new InventoryStock(newest.getId(), product.getId(), slot.getId(), 10));
    }

    @Test
    void allocatesOldestBatchFirstAndContinuesToNextBatch() {
        FifoIssueResult result = service.issue(
            product.getId(), slot.getId(), 7, LocalDate.of(2026, 11, 25),
            "TEST-ISSUE-001", "operator-test"
        );

        assertThat(result.allocations()).extracting(FifoAllocation::batchCode)
            .containsExactly("BATCH-OLD", "BATCH-NEW");
        assertThat(result.allocations()).extracting(FifoAllocation::quantity).containsExactly(5, 2);
        assertThat(stockRepository.findByBatchId(oldest.getId()).get(0).getQuantityOnHand()).isZero();
        assertThat(stockRepository.findByBatchId(newest.getId()).get(0).getQuantityOnHand()).isEqualTo(8);
        assertThat(movementRepository.count()).isEqualTo(2);
    }

    @Test
    void excludesExpiredBatchFromFifoCandidates() {
        InventoryBatch expired = batchRepository.save(new InventoryBatch(
            product.getId(), "BATCH-EXPIRED", LocalDate.of(2026, 11, 10),
            LocalDate.of(2026, 11, 20), 4, "AVAILABLE"
        ));
        stockRepository.save(new InventoryStock(expired.getId(), product.getId(), slot.getId(), 4));

        FifoIssueResult result = service.issue(
            product.getId(), slot.getId(), 3, LocalDate.of(2026, 11, 25),
            "TEST-ISSUE-002", "operator-test"
        );

        assertThat(result.allocations()).extracting(FifoAllocation::batchCode).doesNotContain("BATCH-EXPIRED");
        assertThat(stockRepository.findByBatchId(expired.getId()).get(0).getQuantityOnHand()).isEqualTo(4);
    }

    @Test
    void rollsBackAllChangesWhenEligibleStockIsInsufficient() {
        assertThatThrownBy(() -> service.issue(
            product.getId(), slot.getId(), 99, LocalDate.of(2026, 11, 25),
            "TEST-ISSUE-003", "operator-test"
        )).isInstanceOf(InsufficientStockException.class);

        assertThat(stockRepository.findByBatchId(oldest.getId()).get(0).getQuantityOnHand()).isEqualTo(5);
        assertThat(stockRepository.findByBatchId(newest.getId()).get(0).getQuantityOnHand()).isEqualTo(10);
        assertThat(movementRepository.count()).isZero();
    }

    @Test
    void rejectsZeroQuantity() {
        assertThatThrownBy(() -> service.issue(
            product.getId(), slot.getId(), 0, LocalDate.of(2026, 11, 25),
            "TEST-ISSUE-004", "operator-test"
        )).isInstanceOf(IllegalArgumentException.class);
    }
}
