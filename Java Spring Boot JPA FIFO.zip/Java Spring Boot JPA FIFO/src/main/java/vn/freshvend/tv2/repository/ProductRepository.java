package vn.freshvend.tv2.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import vn.freshvend.tv2.domain.Product;
public interface ProductRepository extends JpaRepository<Product, Long> {}
