package vn.freshvend.tv2.domain;
import jakarta.persistence.*;
@Entity
@Table(name="machine_slot",
 uniqueConstraints=@UniqueConstraint(name="uq_machine_slot_code",columnNames={"machine_id","slot_code"}))
public class MachineSlot {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="slot_id") private Long id;
    @Column(name="machine_id",nullable=false) private Long machineId;
    @Column(name="slot_code",nullable=false,length=30) private String slotCode;
    @Column(name="product_id") private Long productId;
    @Column(nullable=false) private Integer capacity=20;
    @Column(nullable=false,length=24) private String status="ACTIVE";
    protected MachineSlot() {}
    public MachineSlot(Long machineId,String slotCode,Long productId,Integer capacity,String status) {
        this.machineId=machineId; this.slotCode=slotCode; this.productId=productId;
        this.capacity=capacity; this.status=status;
    }
    public Long getId(){return id;}
    public Long getMachineId(){return machineId;}
    public String getSlotCode(){return slotCode;}
    public Long getProductId(){return productId;}
    public Integer getCapacity(){return capacity;}
    public String getStatus(){return status;}
}
