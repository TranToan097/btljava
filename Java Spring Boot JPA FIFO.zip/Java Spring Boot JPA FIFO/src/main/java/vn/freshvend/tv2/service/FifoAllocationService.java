package vn.freshvend.tv2.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import vn.freshvend.tv2.domain.InventoryBatch;
import vn.freshvend.tv2.domain.InventoryMovement;
import vn.freshvend.tv2.domain.InventoryStock;
import vn.freshvend.tv2.repository.InventoryMovementRepository;
import vn.freshvend.tv2.repository.InventoryStockRepository;

@Service
public class FifoAllocationService {
    private final InventoryStockRepository stockRepository;
    private final InventoryMovementRepository movementRepository;

    public FifoAllocationService(InventoryStockRepository stockRepository,
                                 InventoryMovementRepository movementRepository) {
        this.stockRepository = stockRepository;
        this.movementRepository = movementRepository;
    }

    @Transactional
    public FifoIssueResult issue(Long productId, Long slotId, int requestedQuantity,
                                 LocalDate asOfDate, String referenceId, String actorId) {
        if (requestedQuantity <= 0) {
            throw new IllegalArgumentException("requestedQuantity must be greater than zero");
        }
        if (productId == null || slotId == null) {
            throw new IllegalArgumentException("productId and slotId are required");
        }

        LocalDate effectiveDate = asOfDate == null ? LocalDate.now() : asOfDate;
        String effectiveReference = (referenceId == null || referenceId.isBlank())
            ? "POC-" + System.nanoTime() : referenceId;
        String effectiveActor = (actorId == null || actorId.isBlank()) ? "poc-operator" : actorId;

        List<InventoryStock> candidates =
            stockRepository.findFifoCandidatesForUpdate(productId, slotId, effectiveDate);

        int remaining = requestedQuantity;
        List<FifoAllocation> allocations = new ArrayList<>();

        for (InventoryStock stock : candidates) {
            if (remaining == 0) break;

            int allocated = Math.min(stock.getQuantityOnHand(), remaining);
            if (allocated <= 0) continue;

            InventoryBatch batch = stock.getBatch();
            stock.setQuantityOnHand(stock.getQuantityOnHand() - allocated);
            stockRepository.save(stock);

            movementRepository.save(new InventoryMovement(
                productId, stock.getBatchId(), slotId, "ISSUE", -allocated,
                "POC_ISSUE", effectiveReference + "-B" + stock.getBatchId(),
                effectiveActor, "FIFO allocation"
            ));

            allocations.add(new FifoAllocation(batch.getId(), batch.getBatchCode(), allocated));
            remaining -= allocated;
        }

        if (remaining > 0) {
            // Runtime exception triggers transaction rollback of all partial allocations.
            throw new InsufficientStockException(
                "Insufficient eligible stock. Requested=" + requestedQuantity
                    + ", allocated=" + (requestedQuantity - remaining)
            );
        }

        return new FifoIssueResult(productId, slotId, requestedQuantity, List.copyOf(allocations));
    }
}
