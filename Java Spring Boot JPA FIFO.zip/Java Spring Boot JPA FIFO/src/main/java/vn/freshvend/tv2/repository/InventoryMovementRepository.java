package vn.freshvend.tv2.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import vn.freshvend.tv2.domain.InventoryMovement;
public interface InventoryMovementRepository extends JpaRepository<InventoryMovement, Long> {}
