package vn.freshvend.tv2.repository;

import jakarta.persistence.LockModeType;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import vn.freshvend.tv2.domain.InventoryStock;

public interface InventoryStockRepository extends JpaRepository<InventoryStock, Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select s from InventoryStock s join s.batch b " +
           "where s.productId = :productId and s.slotId = :slotId " +
           "and s.quantityOnHand > 0 and b.status = 'AVAILABLE' " +
           "and b.expiryDate >= :asOfDate " +
           "order by b.receivedDate asc, b.expiryDate asc, b.id asc")
    List<InventoryStock> findFifoCandidatesForUpdate(
        @Param("productId") Long productId,
        @Param("slotId") Long slotId,
        @Param("asOfDate") LocalDate asOfDate
    );

    List<InventoryStock> findByBatchId(Long batchId);
}
