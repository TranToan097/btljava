package vn.freshvend.tv2.api;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.freshvend.tv2.service.FifoAllocationService;
import vn.freshvend.tv2.service.FifoIssueResult;

@RestController
@RequestMapping("/api/v1/inventory/issues")
public class InventoryIssueController {
    private final FifoAllocationService fifoAllocationService;

    public InventoryIssueController(FifoAllocationService fifoAllocationService) {
        this.fifoAllocationService = fifoAllocationService;
    }

    @PostMapping
    public ResponseEntity<IssueInventoryResponse> issue(@Valid @RequestBody IssueInventoryRequest request) {
        FifoIssueResult result = fifoAllocationService.issue(
            request.productId(), request.slotId(), request.quantity(),
            request.asOfDate(), request.referenceId(), request.actorId()
        );
        return ResponseEntity.ok(new IssueInventoryResponse(
            true,
            new IssueInventoryResponse.Data(
                result.productId(), result.slotId(), result.requestedQuantity(), result.allocations()
            )
        ));
    }
}
