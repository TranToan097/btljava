package vn.freshvend.tv2.domain;
import jakarta.persistence.*;
import java.time.OffsetDateTime;
@Entity
@Table(name = "inventory_stock",
 uniqueConstraints = @UniqueConstraint(name = "uq_stock_batch_slot", columnNames = {"batch_id","slot_id"}))
public class InventoryStock {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "stock_id") private Long id;
    @Column(name = "batch_id", nullable = false) private Long batchId;
    @Column(name = "product_id", nullable = false) private Long productId;
    @Column(name = "slot_id", nullable = false) private Long slotId;
    @Column(name = "quantity_on_hand", nullable = false) private Integer quantityOnHand;
    @Version @Column(nullable = false) private Long version = 0L;
    @Column(name = "updated_at") private OffsetDateTime updatedAt = OffsetDateTime.now();
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "batch_id", insertable = false, updatable = false)
    private InventoryBatch batch;
    protected InventoryStock() {}
    public InventoryStock(Long batchId, Long productId, Long slotId, Integer quantityOnHand) {
        this.batchId=batchId; this.productId=productId; this.slotId=slotId;
        this.quantityOnHand=quantityOnHand; this.version=0L; this.updatedAt=OffsetDateTime.now();
    }
    public Long getId(){return id;}
    public Long getBatchId(){return batchId;}
    public Long getProductId(){return productId;}
    public Long getSlotId(){return slotId;}
    public Integer getQuantityOnHand(){return quantityOnHand;}
    public InventoryBatch getBatch(){return batch;}
    public void setQuantityOnHand(Integer value) {
        if (value == null || value < 0) throw new IllegalArgumentException("quantityOnHand must be >= 0");
        this.quantityOnHand=value; this.updatedAt=OffsetDateTime.now();
    }
}
