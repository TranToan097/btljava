package vn.freshvend.tv2.domain;
import jakarta.persistence.*;
import java.math.BigDecimal;
@Entity
@Table(name = "product")
public class Product {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id") private Long id;
    @Column(name = "category_id", nullable = false) private Long categoryId;
    @Column(nullable = false, unique = true, length = 50) private String sku;
    @Column(nullable = false, length = 160) private String name;
    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal price;
    @Column(nullable = false, length = 30) private String unit;
    @Column(name = "low_stock_threshold", nullable = false) private Integer lowStockThreshold = 5;
    @Column(nullable = false, length = 24) private String status = "ACTIVE";
    protected Product() {}
    public Product(Long categoryId, String sku, String name, BigDecimal price, String unit) {
        this.categoryId=categoryId; this.sku=sku; this.name=name; this.price=price; this.unit=unit;
    }
    public Long getId(){return id;}
    public Long getCategoryId(){return categoryId;}
    public String getSku(){return sku;}
    public String getName(){return name;}
    public BigDecimal getPrice(){return price;}
    public String getUnit(){return unit;}
    public Integer getLowStockThreshold(){return lowStockThreshold;}
    public String getStatus(){return status;}
}
