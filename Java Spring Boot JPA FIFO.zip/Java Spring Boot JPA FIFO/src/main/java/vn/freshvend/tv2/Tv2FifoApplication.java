package vn.freshvend.tv2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class Tv2FifoApplication {
    public static void main(String[] args) {
        SpringApplication.run(Tv2FifoApplication.class, args);
    }
}
