package vn.freshvend.tv2.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import vn.freshvend.tv2.domain.MachineSlot;
public interface MachineSlotRepository extends JpaRepository<MachineSlot, Long> {}
