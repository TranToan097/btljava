package vn.freshvend.tv2.api;

import java.time.OffsetDateTime;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import vn.freshvend.tv2.service.InsufficientStockException;

@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(InsufficientStockException.class)
    public ResponseEntity<Map<String, Object>> handleInsufficientStock(InsufficientStockException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of(
            "success", false,
            "error", Map.of("code", "INVENTORY_INSUFFICIENT_STOCK", "message", ex.getMessage()),
            "meta", Map.of("timestamp", OffsetDateTime.now().toString())
        ));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> handleBadRequest(IllegalArgumentException ex) {
        return ResponseEntity.badRequest().body(Map.of(
            "success", false,
            "error", Map.of("code", "VALIDATION_ERROR", "message", ex.getMessage()),
            "meta", Map.of("timestamp", OffsetDateTime.now().toString())
        ));
    }
}
