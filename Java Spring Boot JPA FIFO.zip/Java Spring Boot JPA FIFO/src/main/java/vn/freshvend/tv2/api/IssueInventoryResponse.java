package vn.freshvend.tv2.api;
import java.util.List;
import vn.freshvend.tv2.service.FifoAllocation;
public record IssueInventoryResponse(boolean success, Data data) {
    public record Data(Long productId, Long slotId, int requestedQuantity,
                       List<FifoAllocation> allocations) {}
}
