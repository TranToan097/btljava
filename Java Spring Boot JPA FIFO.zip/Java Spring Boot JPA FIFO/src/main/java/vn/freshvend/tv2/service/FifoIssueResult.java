package vn.freshvend.tv2.service;
import java.util.List;
public record FifoIssueResult(Long productId, Long slotId, int requestedQuantity,
                              List<FifoAllocation> allocations) {}
