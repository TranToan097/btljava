package vn.freshvend.tv2.domain;
import jakarta.persistence.*;
import java.time.OffsetDateTime;
@Entity
@Table(name="inventory_movement")
public class InventoryMovement {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="movement_id") private Long id;
    @Column(name="product_id",nullable=false) private Long productId;
    @Column(name="batch_id",nullable=false) private Long batchId;
    @Column(name="slot_id",nullable=false) private Long slotId;
    @Column(name="movement_type",nullable=false,length=24) private String movementType;
    @Column(name="quantity_delta",nullable=false) private Integer quantityDelta;
    @Column(name="reference_type",length=40) private String referenceType;
    @Column(name="reference_id",length=100) private String referenceId;
    @Column(name="actor_id",nullable=false,length=100) private String actorId;
    @Column(name="reason") private String reason;
    @Column(name="created_at") private OffsetDateTime createdAt=OffsetDateTime.now();
    protected InventoryMovement() {}
    public InventoryMovement(Long productId,Long batchId,Long slotId,String movementType,
      Integer quantityDelta,String referenceType,String referenceId,String actorId,String reason) {
        this.productId=productId; this.batchId=batchId; this.slotId=slotId;
        this.movementType=movementType; this.quantityDelta=quantityDelta;
        this.referenceType=referenceType; this.referenceId=referenceId;
        this.actorId=actorId; this.reason=reason; this.createdAt=OffsetDateTime.now();
    }
}
