package vn.freshvend.tv2.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import vn.freshvend.tv2.domain.InventoryBatch;
public interface InventoryBatchRepository extends JpaRepository<InventoryBatch, Long> {}
