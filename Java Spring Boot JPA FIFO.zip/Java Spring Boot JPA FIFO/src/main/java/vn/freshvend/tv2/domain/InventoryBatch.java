package vn.freshvend.tv2.domain;
import jakarta.persistence.*;
import java.time.LocalDate;
@Entity
@Table(name = "inventory_batch")
public class InventoryBatch {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "batch_id") private Long id;
    @Column(name = "product_id", nullable = false) private Long productId;
    @Column(name = "batch_code", nullable = false, length = 60) private String batchCode;
    @Column(name = "received_date", nullable = false) private LocalDate receivedDate;
    @Column(name = "expiry_date", nullable = false) private LocalDate expiryDate;
    @Column(name = "initial_quantity", nullable = false) private Integer initialQuantity;
    @Column(nullable = false, length = 24) private String status = "AVAILABLE";
    protected InventoryBatch() {}
    public InventoryBatch(Long productId, String batchCode, LocalDate receivedDate,
                          LocalDate expiryDate, Integer initialQuantity, String status) {
        this.productId=productId; this.batchCode=batchCode; this.receivedDate=receivedDate;
        this.expiryDate=expiryDate; this.initialQuantity=initialQuantity; this.status=status;
    }
    public Long getId(){return id;}
    public Long getProductId(){return productId;}
    public String getBatchCode(){return batchCode;}
    public LocalDate getReceivedDate(){return receivedDate;}
    public LocalDate getExpiryDate(){return expiryDate;}
    public Integer getInitialQuantity(){return initialQuantity;}
    public String getStatus(){return status;}
}
