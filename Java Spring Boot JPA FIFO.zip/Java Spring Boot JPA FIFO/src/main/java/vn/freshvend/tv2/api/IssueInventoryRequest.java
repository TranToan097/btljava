package vn.freshvend.tv2.api;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
public record IssueInventoryRequest(
    @NotNull Long productId,
    @NotNull Long slotId,
    @Min(1) int quantity,
    LocalDate asOfDate,
    String referenceId,
    String actorId
) {}
