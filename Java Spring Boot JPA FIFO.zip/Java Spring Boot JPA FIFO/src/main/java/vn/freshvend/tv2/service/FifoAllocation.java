package vn.freshvend.tv2.service;
public record FifoAllocation(Long batchId, String batchCode, int quantity) {}
