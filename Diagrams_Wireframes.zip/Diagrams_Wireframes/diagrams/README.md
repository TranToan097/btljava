# TV2 Diagrams

- `source/`: editable Graphviz DOT, Mermaid and PlantUML sources.
- `rendered/`: SVG previews for browser, VS Code, Figma import or documentation.
- ERDs cover Product/Category, Inventory/Batch/Restock and Machine/Location/Slot/Audit.
- Activity diagrams cover Restock and FIFO issue; state diagrams cover Batch and Slot; Class Diagram covers Product/Inventory/Slot.
- Shared Machine/Slot IDs and final ownership must be reconciled with TV4 before team-wide schema merge.
